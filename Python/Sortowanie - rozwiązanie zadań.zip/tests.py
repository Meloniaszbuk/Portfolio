import unittest
from exercise import *


class TestFunctions(unittest.TestCase):
    def test_test(self):
        self.assertTrue(True)
