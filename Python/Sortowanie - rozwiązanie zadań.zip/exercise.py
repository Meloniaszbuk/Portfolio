from typing import List, Tuple


def quicksort(in_array: List[int]) -> List[int]:
    """Posortuj zakres tablicy metodą quicksort.

    :param in_array: tablica do posortowania
    :return: posortowana tablica
    """

    return None


def bubblesort(in_array: List[int]) -> Tuple[List[int], int]:
    """Posortuj tablicę metodą bąbelkową.

    :param in_array: tablica do posortowania
    :return: krotka zawierająca posortowaną tablicę oraz liczbę wykonanych porównań
    """

    return None, 0
