from typing import List, Dict


def adjmat_to_adjlist(adjmat: List[List[int]]) -> Dict[int, List[int]]:
    pass


def dfs_recursive(G: Dict[int, List[int]], s: int) -> List[int]:
    pass
 

def dfs_iterative(G: Dict[int, List[int]], s: int) -> List[int]:
    pass


def is_acyclic(G: Dict[int, List[int]]) -> bool:
    pass
